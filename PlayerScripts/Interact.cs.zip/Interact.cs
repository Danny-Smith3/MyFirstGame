using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interact : MonoBehaviour {

    public Transform camera;

    // Update is called once per frame
    void Update() {
        if (Input.GetKey("e")) {
            RaycastHit hit;
            if (Physics.Raycast(camera.position, camera.TransformDirection(Vector3.forward), out hit, 5f)) {
                if (hit.transform.tag == "Keycard") {
                    Debug.Log("found keycard");
                    Keycard key = gameObject.GetComponent<Keycard>();
                    key.setKeyCard();
                    Show showCard = hit.transform.GetComponent<Show>();
                    showCard.showKey(false);
                }
                if (hit.transform.tag == "KeycardReader") {
                    Debug.Log("found keycard reader");
                    Keycard keycard = gameObject.GetComponent<Keycard>();
                    if (keycard.getKeyCard()) {
                        Debug.Log("deactivating force field");
                        MeshRenderer forceFieldRend = hit.transform.parent.GetComponent<MeshRenderer>();
                        MeshCollider forceFieldCollider = hit.transform.parent.GetComponent<MeshCollider>();
                        forceFieldRend.enabled = false;
                        forceFieldCollider.enabled= false;
                    }   
                }
                if (hit.transform.name == "Bomb") {
                    Debug.Log("Bomb found");
                    Timer bomb = hit.transform.GetComponent<Timer>();
                    bomb.bombDisable();
                    Debug.Log("Bomb Disarmed");
                }
                if (hit.transform.name == "AmmoBox") {
                    Debug.Log("Ammo box found");
                    AmmoBox ammo = hit.transform.GetComponent<AmmoBox>();
                    GunScript gun = gameObject.GetComponent<GunScript>();
                    gun.ammoTotal = 90;
                    ammo.useAmmoBox();
                }
            }
        }
    }
}
