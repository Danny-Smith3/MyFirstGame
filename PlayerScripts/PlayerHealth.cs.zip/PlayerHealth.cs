using UnityEngine;
using TMPro;
using UnityEngine.UIElements;

public class PlayerHealth : MonoBehaviour {

    private float health = 100f;
    public TMP_Text healthText;
    //this doesn't work for some reason
    public Image healthBar;

    void Start() {
    }

    // Update is called once per frame
    void Update() {
        if (health <= 0) {
            //game over
        }
    }

    public void takeDamage(float damage) {
        health -= damage;
        // -.6 x scale for health bar
        // -30 x position
    }
}
