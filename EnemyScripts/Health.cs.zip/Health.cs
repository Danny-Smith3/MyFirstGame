using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour {

    private float health;
    public GameObject keycard;
    public bool hasKey = false;

    void Start() {
        keycard = GameObject.Find("Keycard");
        health = 100f;
    }

    // Update is called once per frame
    void Update() {
        if (health <= 0) {
            //death animation will be implemented after mvp
            if (hasKey) {
                dropKeyCard();
            }
            Destroy(gameObject);
        }
    }

    public void takeDamage(float damage) {
        health -= damage;
    }

    private void dropKeyCard() {
        Show key = keycard.GetComponent<Show>();
        key.enemyAlive(false);
        key.showKey(true);
    }
}
